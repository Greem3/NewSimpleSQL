import NewSimpleSQL
from NewSimpleSQL.SimpleSQLite import Database, generate_id