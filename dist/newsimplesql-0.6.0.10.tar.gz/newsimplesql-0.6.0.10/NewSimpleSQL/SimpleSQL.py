import sqlalchemy, cython
import warnings

if __name__ == "__main__":
    raise ImportError("This file is not yet finished. Only SimpleSQLite can be used")
else:
    warnings.warn("This module is not yet finished and may not work as expected.")