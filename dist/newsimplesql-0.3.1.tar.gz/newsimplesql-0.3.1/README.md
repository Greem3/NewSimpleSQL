# PySimpleSQL

## English
Use the easiest SQL programming language with PySimpleSQL!

For now, it only has support for SQLite3

### Download

`pip install NewSimpleSQL`

## Español
¡Utiliza el lenguaje de programación SQL más facil con PySimpleSQL!

Por ahora, solo tiene soporte son SQLite3

### Descarga

`pip install NewSimpleSQL`